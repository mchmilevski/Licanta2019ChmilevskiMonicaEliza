import React from 'react';
import {AppState, AsyncStorage, Alert, StyleSheet} from 'react-native';
import {Container, Content, Spinner, Icon, Button} from 'native-base';
import {loadObject, saveObject} from "../utils/AsyncStorageUtils";
import SpentReceivedTabs from "../components/SpentReceivedTabs";
import PlusMinusButton from "../components/PlusMinusButton";
import {total, totalPerWeek, maxCategoryPerWeek} from "../utils/TotalUtils";
import {getFullMonthYearWithoutCurrentYear, nextDay} from "../utils/DateUtils";
import {getNotificationsPermissionsAsync} from "../utils/PermissionsUtils";
import {sendLocalNotification} from "../utils/NotificationUtils";
import {Notifications} from "expo";

export default class HomeScreen extends React.Component {
    updatedCurrentMonthElem = false;

    state = {
        list: [],
        spinner: true,
        currentTabOperation: 'Spent',
        budget: '',
    };

    static navigationOptions = ({navigation}) => ({
        title: "Money List",
        headerRight: (
            <Button transparent onPress={() => navigation.navigate("Dashboard", {budget: navigation.getParam('budget'),
                                                                                 updateBudget: navigation.getParam('updateBudget'),
                                                                                 listOfItems: navigation.getParam('listOfItems'),
                                                                                 operation: navigation.getParam('operation')})}
            >
                <Icon name="ios-stats" style={{fontSize: 25, color: navigation.getParam('operation') === 'Spent' ? '#cc3939' : '#228e53'}}/>
            </Button>
        )
    });

    componentDidMount() {
        getNotificationsPermissionsAsync();
        loadObject("moneyList").then(loadedObject => {
            if (loadedObject !== null) {
                this.setState({
                    list: loadedObject.list,
                    budget: loadedObject.budget,
                });
                this.props.navigation.setParams({budget: loadedObject.budget});
                this.props.navigation.setParams({listOfItems: loadedObject.list});
            }
            this.props.navigation.setParams({updateBudget: this.updateBudget});
            this.props.navigation.setParams({operation: this.state.currentTabOperation});
            this.setState({spinner: false});
        });
        // AsyncStorage.clear();

        AppState.addEventListener('change', this._handleAppStateChange);
    }

    componentWillUnmount() {
        AppState.removeEventListener('change', this._handleAppStateChange);
    }

    _handleAppStateChange = (nextAppState) => {
        // Shows the "less than 10% bugdet" notification when the app goes in background and an element from the currentMonth was updated.
        if (nextAppState.match(/inactive|background/) && this.updatedCurrentMonthElem) {
            const totalSpent = total(this.state.list, "Spent", getFullMonthYearWithoutCurrentYear(new Date()));
            if (totalSpent < this.state.budget && totalSpent > 90 / 100 * this.state.budget) {
                sendLocalNotification("Budget", "Less then 10% until reaching the budget for this month", Date.now() + 1000)
            }
            this.updatedCurrentMonthElem = false;
        }
    };

    componentDidUpdate(nextProps, nextState, nextContext) {
        // Cancel the weekly notification set at the previous update
        Notifications.cancelAllScheduledNotificationsAsync();

        // Set the weekly notification starting next Sunday (day 0 of the week) at hour 22:00
        const spentLastWeek = totalPerWeek(nextState.list, "Spent");
        const receivedLastWeek = totalPerWeek(nextState.list, "Received");
        const maxSpentCategoryTotal = maxCategoryPerWeek(nextState.list, "Spent");
        const maxReceivedCategoryTotal = maxCategoryPerWeek(nextState.list, "Received");

        const nextSunday = nextDay(0);
        nextSunday.setHours(22, 0, 0, 0);

        let notificationMessage = `You spent ${spentLastWeek} and received ${receivedLastWeek}.`;
        if (maxSpentCategoryTotal) {
            notificationMessage += `\nMost spent on ${maxSpentCategoryTotal.category} ${maxSpentCategoryTotal.total}.`;
        }
        if (maxReceivedCategoryTotal) {
            notificationMessage += `\nMost received on ${maxReceivedCategoryTotal.category} ${maxReceivedCategoryTotal.total}.`;
        }
        sendLocalNotification("Last Week", notificationMessage, nextSunday.getTime(), 'week');

        // To see each minute how the weekly notification looks, uncomment this line.
        // sendLocalNotification("Last Week", notificationMessage, Date.now() + 5000, 'minute');
    }

    /*
     * Used in updateList and editElementList.
     */
    _checkBudgetCurrentMonth = (item) => {
        if (getFullMonthYearWithoutCurrentYear(item.date) === getFullMonthYearWithoutCurrentYear(new Date())) {
            this.updatedCurrentMonthElem = true;
            const totalSpent = total(this.state.list, "Spent", getFullMonthYearWithoutCurrentYear(new Date()));
            if (this.state.currentTabOperation === 'Spent' && this.state.budget !== '' && totalSpent > this.state.budget) {
                Alert.alert("Budget", "Exceeded budget for this month");
            }
        }
    };

    updateBudget = (newBudget) => {
        this.props.navigation.setParams({budget: newBudget});
        this.setState({budget: newBudget}, () => {
            saveObject("moneyList", this.state);
        });
    };

    /*
     * Receives a new element from AddMoneyScreen. The list is updated with the new element.
     */
    updateList = (values) => {
        if (values.money === '' || values.notes === '' || values.category === '') {
            return;
        }

        this.setState({list: [...this.state.list, values].sort((a, b) => b.date - a.date)}, () => {
            this._checkBudgetCurrentMonth(values);
            saveObject("moneyList", this.state);
            this.props.navigation.setParams({listOfItems: this.state.list});
        });
    };

    /*
     * Used after an element is selected in HomeScreenList and edited in AddMoneyScreen.
     */
    editElementList = (elem) => {
        this.setState({list: this.state.list.sort((a, b) => b.date - a.date)}, () => {
            this._checkBudgetCurrentMonth(elem);
            saveObject("moneyList", this.state);
            this.props.navigation.setParams({listOfItems: this.state.list});
        });
    };

    /*
     * Used after an element is deleted in HomeScreenList.
     */
    deleteElement = (index) => {
        const arrayTemp = [...this.state.list];
        arrayTemp.splice(index, 1);

        this.setState({list: arrayTemp}, () => {
            saveObject("moneyList", this.state);
            this.props.navigation.setParams({listOfItems: this.state.list});
        });
    };


    /*
     * Indicates the currentTabOperation selected in SpentReceivedTabs.
     */
    updateOperation = (value) => {
        this.setState({
            currentTabOperation: value ? 'Spent' : 'Received'
        }, () => {
            this.props.navigation.setParams({operation: this.state.currentTabOperation});
        })
    };

    /*
     * Since componentWillMount() loads async from memory the 'moneyList', it'll show a spinner, then SpentReceivedTabs is rendered with the list.
     */
    showSpentReceivedTabs = () => {
        if (this.state.spinner) {
            return (<Spinner animating={this.state.spinner} style={{flex: 1, alignItems: 'center'}} color={'#5a4960'}/>);
        }

        return (
            <Content>
                <SpentReceivedTabs listOfItems={this.state.list}
                                   updateSpentOperation={this.updateOperation}
                                   navigation={this.props.navigation}
                                   editElementList={this.editElementList}
                                   deleteElement={this.deleteElement}
                />
            </Content>
        );
    };

    render() {
        return (
            <Container>
                {this.showSpentReceivedTabs()}
                <PlusMinusButton navigation={this.props.navigation} updateList={this.updateList} operation={this.state.currentTabOperation}/>
            </Container>
        );
    }
}

const styles = StyleSheet.create({
    container: {
        backgroundColor: '#fff',
        paddingTop: 40
    },
    item: {
        padding: 10,
        fontSize: 18,
        height: 44,
    },
    button: {
        alignItems: 'flex-start'
    }
});
