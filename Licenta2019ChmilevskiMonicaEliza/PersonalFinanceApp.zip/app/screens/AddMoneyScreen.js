import React, {Component} from 'react';
import {View, StyleSheet, TextInput} from 'react-native';
import {
    Container,
    DatePicker,
    Form,
    Item,
    Input,
    Label,
    Icon,
    Button,
    Picker
} from 'native-base';
import {getFormatedDate} from "../utils/DateUtils";

export default class AddMoneyModal extends Component {
    state = {
        form: {
            money: '',
            notes: '',
            date: new Date(),
            operation: '',
            description: '',
            category: ''
        }
    };

    static navigationOptions = ({navigation}) => ({
        title: navigation.getParam('currentElementOfList') ? 'Edit' : (navigation.getParam('operation') === 'Spent' ? 'Spent Money' : 'Received Money'),
        headerRight: (
            <View style={{flexDirection: "row"}}>
                <Button transparent onPress={() => {
                    navigation.navigate('CameraScreen', {onGoBack: (scannedReceipt) => navigation.getParam('updateFormReceipt')(scannedReceipt)});
                }}>
                    <Icon name="ios-camera" style={{fontSize: 30, paddingBottom: 30}}/>
                </Button>
                <Button transparent onPress={() => {
                    const handleSubmit = navigation.getParam('handleSubmit');
                    handleSubmit();
                    navigation.goBack()
                }}>
                    <Icon name="checkmark" style={{fontSize: 40, paddingBottom: 40}}/>
                </Button>
            </View>
        )
    });

    componentDidMount() {
        this.props.navigation.setParams({handleSubmit: this.handleSubmit});
        this.props.navigation.setParams({updateFormReceipt: this.updateFormReceipt});

        const currentElementOfList = this.props.navigation.getParam('currentElementOfList');
        const operation = this.props.navigation.getParam('operation');

        if (operation) {
            this.setState({form: {...this.state.form, operation: operation}});
        }

        if (currentElementOfList) {
            this.setState({
                form: currentElementOfList
            });
        }
    }

    updateFormReceipt = (scannedReceipt) => {
        this.setState({form: {...this.state.form, money: scannedReceipt.money, date: scannedReceipt.date, notes: scannedReceipt.notes}});
    };

    handleSubmit = () => {
        const currentElementOfList = this.props.navigation.getParam('currentElementOfList');
        const editElementList = this.props.navigation.getParam('editElementList');
        const updateList = this.props.navigation.getParam('updateList');

        if (editElementList) {
            if (this.state.form.money === '' || this.state.form.notes === '' || !this.state.form.category || this.state.form.category === '') {
                return;
            }

            currentElementOfList.operation = this.state.form.operation;
            currentElementOfList.money = this.state.form.money;
            currentElementOfList.date = this.state.form.date;
            currentElementOfList.notes = this.state.form.notes;
            currentElementOfList.category = this.state.form.category;
            currentElementOfList.description = this.state.form.description;
            editElementList(currentElementOfList);
        } else {
            updateList(this.state.form);
        }
    };

    render() {
        return (
            <Container>
                <Form>
                    {/* TODO Add Validations */}
                    <View>
                        <Item stackedLabel>
                            <Label style={this.state.form.operation === 'Spent' ? {color: '#cc3939'} : {color: '#228e53'}}>Date</Label>
                        </Item>

                        <View style={{position: 'absolute', marginTop: 25, width: '100%'}}>
                            <DatePicker
                                textStyle={styles.datePicker}
                                defaultDate={this.props.navigation.getParam('currentElementOfList') ? this.props.navigation.getParam('currentElementOfList').date : this.state.form.date}
                                minimumDate={new Date(1900, 1, 1)}
                                maximumDate={new Date()}
                                placeHolderText={getFormatedDate(this.state.form.date)}
                                formatChosenDate={date => getFormatedDate(date)}
                                placeHolderTextStyle={{marginLeft: 5}}
                                locale={"en"}
                                timeZoneOffsetInMinutes={undefined}
                                modalTransparent={true}
                                animationType={"slide"}
                                androidMode={"default"}
                                onDateChange={(date) => this.setState({form: {...this.state.form, date: date}})}
                                disabled={false}
                            />
                        </View>
                    </View>
                    <Item stackedLabel>
                        <Label style={this.state.form.operation === 'Spent' ? {color: '#cc3939'} : {color: '#228e53'}}>Categories</Label>
                        <Picker
                            style={{marginRight: 20}}
                            mode="dropdown"
                            iosIcon={<Icon name="arrow-down"/>}
                            selectedValue={this.state.form.category}
                            onValueChange={(category) => this.setState({
                                form: {
                                    ...this.state.form,
                                    category: category
                                }
                            })}
                        >
                            {
                                this.state.form.operation === 'Spent' ? [
                                    <Picker.Item label="Grocery" value="Grocery"/>,
                                    <Picker.Item label="Restaurants" value="Restaurants"/>,
                                    <Picker.Item label="Shopping" value="Shopping"/>,
                                    <Picker.Item label="Car" value="Car"/>,
                                    <Picker.Item label="House" value="House"/>,
                                    <Picker.Item label="School" value="School"/>,
                                    <Picker.Item label="Saving" value="Saving"/>,
                                    <Picker.Item label="Fun activities" value="Fun activities"/>,
                                    <Picker.Item label="Travel" value="Travel"/>,
                                    <Picker.Item label="Sports" value="Sports"/>,
                                    <Picker.Item label="Health" value="Health"/>,
                                    <Picker.Item label="Animals" value="Animals"/>,

                                ] : [
                                    <Picker.Item label="Gift" value="Gift"/>,
                                    <Picker.Item label="Salary" value="Salary"/>,
                                    <Picker.Item label="Family" value="Family"/>,
                                    <Picker.Item label="Rent" value="Rent"/>,
                                ]
                            }

                        </Picker>
                    </Item>
                    <Item stackedLabel>
                        <Label style={this.state.form.operation === 'Spent' ? {color: '#cc3939'} : {color: '#228e53'}}>Money</Label>
                        <Input
                            onChangeText={(money) => this.setState({form: {...this.state.form, money: money}})}
                            keyboardType={'numeric'}
                            value={this.state.form.money}
                        />
                    </Item>

                    <Item stackedLabel>
                        <Label style={this.state.form.operation === 'Spent' ? {color: '#cc3939'} : {color: '#228e53'}}>Notes</Label>
                        <Input onChangeText={(notes) => this.setState({
                            form: {
                                ...this.state.form,
                                notes: notes
                            }
                        })}
                               value={this.state.form.notes}/>
                    </Item>
                    {/*<TextInput*/}
                        {/*placeholder="Description"*/}
                        {/*style={{height: '20%', borderColor: 'grey', borderWidth: 1}}*/}
                        {/*multiline={true}*/}
                        {/*onChangeText={(description) => this.setState({*/}
                            {/*form: {*/}
                                {/*...this.state.form,*/}
                                {/*description: description*/}
                            {/*}*/}
                        {/*})}*/}
                        {/*value={this.state.form.description}*/}

                    {/*/>*/}
                </Form>
            </Container>
        )
            ;
    }
}

const styles = StyleSheet.create({
    headerTitle: {
        color: '#666666',
        textAlign: 'center'
    },
    headerStyle: {
        height: 65,
    },
    modalContainer: {
        marginTop: 150,
        marginLeft: 30,
        marginRight: 30,
        backgroundColor: '#D3D3D3',
    },
    buttonView: {
        paddingTop: 50,
        width: '100%',
    },
    buttonAdd: {
        borderColor: '#ded3e2',
        backgroundColor: '#ded3e2',
        display: 'flex',
        justifyContent: 'space-around',
        width: 100,
        marginLeft: 140,
    },
    textButton: {
        paddingRight: 12,
        color: '#666666',
    },
    iconAdd: {
        color: '#666666',
    },
    modalButtons: {
        flexDirection: 'row',
        justifyContent: 'space-around',
        paddingTop: 50,
    },
    buttonSaveCancel: {
        width: 100,
        backgroundColor: '#ded3e2',
        display: 'flex',
        justifyContent: 'center',
        alignItems: 'center'
    },
    textButtonModal: {
        color: '#666666',
    },
    operationDropdown: {
        // marginLeft: 13
    },
    datePicker: {
        // marginRight: 250,
        marginLeft: 5
    }
});
