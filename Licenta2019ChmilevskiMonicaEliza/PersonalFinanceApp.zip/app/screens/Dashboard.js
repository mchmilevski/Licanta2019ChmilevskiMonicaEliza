import React from 'react';
import {Content, Text, Body, Container, Card, CardItem, Icon, Item, Form, Input, Button} from 'native-base'
import MonthTabs from "../components/MonthTabs";
import {getFullMonthYearWithoutCurrentYear} from "../utils/DateUtils";
import {totalPerCategory, total} from '../utils/TotalUtils';
import {StyleSheet, Keyboard, View} from "react-native";
import {getCategoryIcon} from "../utils/CategoriesIcons";
import {shuffleArray} from "../utils/ArrayUtils";
import {VictoryPie} from "victory-native";

export default class Dashboard extends React.Component {
    state = {
        operation: '',
        currentMonth: '',
        budget: ''
    };

    static navigationOptions = ({navigation}) => ({
        title: `${navigation.getParam('operation')} Dashboard`
    });

    componentDidMount() {
        this.setState({budget: this.props.navigation.getParam('budget')})
        this.setState({operation: this.props.navigation.getParam('operation')})
    }

    updateCurrentMonth = (date) => {
        this.setState({currentMonth: getFullMonthYearWithoutCurrentYear(date)})
    };

    createCardItemsForMonthlyCategories = () => {
        let categoryTotalArray = this.getCategoryTotalArray(this.state.operation, this.state.currentMonth);
        categoryTotalArray.sort((a, b) => b.total - a.total);

        const cardItemMap = [];
        for(let i = 0; i < categoryTotalArray.length; i++) {
            cardItemMap.push(
                <CardItem style={{borderBottomColor: '#6d6b6b', borderBottomWidth: 0.3}}>
                    <Body style={styles.listItemContent}>
                        <View style={{flex: 1, flexDirection: 'row'}}>
                            <Icon style={{color: '#6d6b6b'}} name={getCategoryIcon(categoryTotalArray[i].category, this.state.operation)}/>
                            <Text style={{fontSize: 18, paddingLeft: 20}}>{categoryTotalArray[i].category}</Text>
                        </View>
                        <Text style={{fontSize: 23, marginLeft: 100, color: this.state.operation === 'Spent' ? '#cc3939' : '#228e53'}}>{categoryTotalArray[i].total}</Text>
                    </Body>
                </CardItem>
            )
        }
        return cardItemMap;
    };

    getCategoryTotalArray = (operation, month) => {
        let categoryTotalMap = new Map();
        const elementsList = this.props.navigation.getParam('listOfItems');
        for (let i = 0; i < elementsList.length; i++) {
            if(elementsList[i].operation === operation && getFullMonthYearWithoutCurrentYear(elementsList[i].date) === month) {
                const total = totalPerCategory(elementsList, elementsList[i].category, operation, month);
                categoryTotalMap.set(elementsList[i].category, {category: elementsList[i].category, total: total});
            }
        }
        return Array.from(categoryTotalMap.values());
    };

    render() {
        const {navigation} = this.props;
        const listOfItems = navigation.getParam('listOfItems');

        const categoryTotalArray = this.getCategoryTotalArray(this.state.operation, this.state.currentMonth)
            .map (item => ({x: item.category, y: item.total}));

        return (
            <Container>
                <Content>
                    <MonthTabs listOfItems={listOfItems} spentList={this.state.operation === 'Spent'} updateCurrentMonth={this.updateCurrentMonth}/>
                    <View pointerEvents='none' style={categoryTotalArray.length ? {marginTop: -50, marginBottom: -20} : {display: 'none'}}>
                        <VictoryPie
                            radius={100}
                            data={categoryTotalArray}
                            padAngle={3}
                            innerRadius={60}
                            labels={item => item.x}
                            labelRadius={110}
                            colorScale={shuffleArray(["#d22780", "#f8b500", "#5e227f", "#ff5959",
                                                            "#40a798", "#226b80", "#5a3921", "#e3c4a8",
                                                            "#58b368", "#33313b", "#ab93c9", "#ff8246"])}
                        />
                    </View>
                    <Card style={getFullMonthYearWithoutCurrentYear(new Date()) === this.state.currentMonth && this.state.operation === 'Spent' ? styles.cardStyle : {display: 'none'}}>
                        <CardItem style={{backgroundColor: '#cc3939'}} header bordered>
                            <Text style={{fontSize: 18, color: '#fff'}}>Set the budget for this month</Text>
                        </CardItem>
                        <CardItem>
                            <Body style={{flex: 1, flexDirection: 'row', justifyContent: 'space-around'}}>
                                <Form>
                                    <Item rounded style={{width: 200}}>
                                        <Input
                                            onChangeText={(budget) => this.setState({budget: budget})}
                                            placeholder="Set budget"
                                            value={this.state.budget}
                                            keyboardType={'numeric'}
                                        />
                                    </Item>
                                </Form>
                                <Button transparent onPress={() => {
                                    navigation.getParam('updateBudget')(this.state.budget);
                                    Keyboard.dismiss()
                                }}>
                                    <Icon name="checkmark" style={{color: '#cc3939', fontSize: 50}}/>
                                </Button>
                            </Body>
                        </CardItem>
                    </Card>
                    <Card style={styles.cardStyle}>
                        <CardItem style={{backgroundColor: this.state.operation === 'Spent' ? '#cc3939' : '#228e53'}} header bordered>
                            <Text style={{fontSize: 18, color: '#fff'}}>{this.state.operation} this month</Text>
                        </CardItem>
                        <CardItem>
                            <Body style={[styles.listItemContent, {justifyContent: 'center'}]}>
                                <Text style={{fontSize: 23, color: this.state.operation === 'Spent' ? '#cc3939' : '#228e53'}}>{total(listOfItems, this.state.operation, this.state.currentMonth)}</Text>
                            </Body>
                        </CardItem>
                    </Card>
                    <Card style={styles.cardStyle}>
                        <CardItem style={{backgroundColor: this.state.operation === 'Spent' ? '#cc3939' : '#228e53'}} header bordered>
                            <Text style={{fontSize: 18, color: '#fff'}}>{this.state.operation === 'Spent' ? 'Spent on' : 'Received from'}</Text>
                        </CardItem>
                        {this.createCardItemsForMonthlyCategories()}
                    </Card>
                </Content>
            </Container>
        )
    }
}

const styles = StyleSheet.create({
    cardStyle: {
        width: '90%',
        marginLeft: '5.3%',
        marginBottom: 30
    },
    listItemContent: {
        height: 37,
        flex: 1,
        flexDirection: 'row',
        justifyContent: 'space-between'
    }
});
