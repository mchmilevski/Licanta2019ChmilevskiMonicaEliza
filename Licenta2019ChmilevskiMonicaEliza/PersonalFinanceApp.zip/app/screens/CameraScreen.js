import {TouchableOpacity, Text, View} from "react-native";
import {Camera} from "expo";
import React from "react";
import {getCameraPermissionsAsync} from "../utils/PermissionsUtils";
import {Icon, Spinner} from "native-base";

export default class CameraScreen extends React.Component {
    state = {
        spinner: false,
    };

    static navigationOptions = {
        title: "Scan Receipt"
    };

    componentDidMount() {
        getCameraPermissionsAsync();
    }

    takePictureCallback = async ({uri, width, height, exif, base64}) => {
        console.log(base64.substring(0, 100));
        this.setState({spinner: true});

        const url = await this.postImgur(base64);
        console.log(url);
        const ocrText = await this.postOCRSpace(url);
        // const ocrText = await this.postOCRSpace("https://i.imgur.com/hgI69G6.jpg");
        console.log(ocrText, "ocrText");
        const scannedReceipt = this.parseOCRSpaceText(ocrText);
        this.props.navigation.getParam('onGoBack')(scannedReceipt);
        this.props.navigation.goBack();
    };

    postImgur = async (base64) => {
        const data = new FormData();
        data.append("image", base64);
        data.append("type", "base64");
        const response = await fetch('https://api.imgur.com/3/upload', {
            method: 'POST',
            headers: {
                Authorization: 'Client-ID f77e3513e7f4d24',
            },
            body: data
        });
        console.log(response, "postImgur");
        return JSON.parse(response._bodyText).data.link;
    };

    postOCRSpace = async (url) => {
        const data = new FormData();
        data.append("language", "eng");
        data.append("detectOrientation", "true");
        data.append("url", url);
        data.append("scale", "true");
        data.append("isTable", "true");
        const response = await fetch('https://api.ocr.space/parse/image/', {
            method: 'POST',
            headers: {
                apikey: 'df4b8c360c88957',
            },
            body: data
        });
        console.log(response, "postOCRSpace");
        return JSON.parse(response._bodyText).ParsedResults[0].ParsedText;
    };

    parseOCRSpaceText = (ocrText) => {
        const money = this.getTotal(ocrText);
        console.log("Total: " + money);
        const date = this.getDate(ocrText);
        console.log("Date: " + date);
        const notes = this.getStore(ocrText);
        console.log("Store: " + notes);

        return {money: money, date: date, notes: notes};
    };

    getTotal = (ocrText) => {
        if (ocrText.match(/\d+( ?(\.|,) ?)\d{2} /gmi)) {
            const possibleTotalArrayStr = ocrText.match(/\d+( ?(\.|,) ?)\d{2} /gmi);
            const possibleTotalsArray = possibleTotalArrayStr.map(item => Number(item.replace(/ ?(\.|,) ?/gmi, '.')));
            const possibleTotal = Math.max(...possibleTotalsArray);
            if (isNaN(possibleTotal)) {
                return '';
            }
            return String(possibleTotal);
        }
        return '';
    };

    getDate = (ocrText) => {
        if (ocrText.match(/(\d{2}( ?( |\.|-|\/) ?\d{2} ?( |\.|-|\/) ?)\d{4})|(\d{4}( ?( |\.|-|\/) ?\d{2} ?( |\.|-|\/) ?)\d{2})/gmi)) {
            const possibleDateStr = ocrText.match(/(\d{2}( ?( |\.|-|\/) ?\d{2} ?( |\.|-|\/) ?)\d{4})|(\d{4}( ?( |\.|-|\/) ?\d{2} ?( |\.|-|\/) ?)\d{2})/gmi)[0];
            let possibleDay;
            let possibleYear;
            if (possibleDateStr.match(/^\d{2}\D+/gmi)) {
                possibleDay = Number(possibleDateStr.match(/^\d{2}/gmi)[0]);
                possibleYear = Number(possibleDateStr.match(/\d{4}$/gmi)[0]);
            } else if (possibleDateStr.match(/^\d{4}/gmi)) {
                possibleDay = Number(possibleDateStr.match(/\d{2}$/gmi)[0]);
                possibleYear = Number(possibleDateStr.match(/^\d{4}/gmi)[0]);
            } else {
                return new Date();
            }
            const possibleMonth = Number(possibleDateStr.match(/\D+\d{2}\D+/gmi)[0].match(/\d{2}/gmi)) - 1;
            const possibleDate = new Date();
            possibleDate.setFullYear(possibleYear, possibleMonth, possibleDay);
            return possibleDate;
        }
        return new Date();
    };

    getStore = (ocrText) => {
        const store = ocrText.split(" \t\r\n");
        if (store.length < 2) {
            return '';
        }
        return store[0] + " " + store[1];
    };

    render() {
        if (this.state.spinner) {
            return (
                <View style={{flex: 1, alignItems: 'center', justifyContent: 'center'}}>
                    <Spinner animating={this.state.spinner} color={'#5a4960'}/>
                    <Text>Processing Image</Text>
                </View>
            );
        }

        return (
            <Camera style={{flex: 1}} ref={ref => this.camera = ref}>
                <TouchableOpacity
                    style={{flex: 1, justifyContent: 'flex-end', alignItems: 'center'}}
                    onPress={() => {
                        this.camera.takePictureAsync({base64: true, onPictureSaved: this.takePictureCallback});
                        setTimeout(() => this.forceUpdate(), 1);
                    }}
                >
                    <Icon name="ios-radio-button-off" color='white' style={{fontSize: 100, marginLeft: 20, marginBottom: 30, color: 'white'}}/>
                </TouchableOpacity>
            </Camera>
        );
    }
}
