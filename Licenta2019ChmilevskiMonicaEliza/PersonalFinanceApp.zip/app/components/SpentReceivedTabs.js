import React from 'react';
import {StyleSheet, View} from 'react-native';
import {Content, Button, Text} from 'native-base';
import HomeScreenList from "./HomeScreenList";
import MonthTabs from "./MonthTabs";
import {getFullMonthYearWithoutCurrentYear} from "../utils/DateUtils";
import {total} from "../utils/TotalUtils";

export default class SpentReceivedTabs extends React.Component {
    state = {
        spentList: true,
        currentMonth: ''
    };

    updateCurrentMonth = (date) => {
        this.setState({currentMonth: getFullMonthYearWithoutCurrentYear(date)})
    };

    // TODO: Disabled button when is selected a list

    render() {
        const {listOfItems, navigation} = this.props;
        return (
            <Content>
                <View style={styles.buttonsContent}>
                    <Button full transparent style={this.state.spentList ? [styles.buttonsStyle, styles.borderStyleActiveSpent] : [styles.buttonsStyle] } onPress={() => {this.setState({spentList: true});
                        this.props.updateSpentOperation(true);
                    }}>
                        <View style={styles.textStyleButtons}>
                            <Text style={[styles.titleBox, styles.colorSpent]}>Spent</Text>
                            <Text style={[styles.numberStyle, styles.colorSpent]}>{total(listOfItems, 'Spent', this.state.currentMonth)}</Text>
                        </View>
                    </Button>

                    <Button full transparent style={this.state.spentList ? [styles.buttonsStyle] : [styles.buttonsStyle, styles.borderStyleActiveReceived]} onPress={() => {this.setState({spentList: false});
                        this.props.updateSpentOperation(false);
                    }}>
                        <View style={styles.textStyleButtons}>
                            <Text style={[styles.titleBox, styles.colorReceived]}>Received</Text>
                            <Text style={[styles.numberStyle,styles.colorReceived]}>{total(listOfItems, 'Received', this.state.currentMonth)}</Text>
                        </View>
                    </Button>
                </View>
                <MonthTabs listOfItems={listOfItems} spentList={this.state.spentList} updateCurrentMonth={this.updateCurrentMonth}/>
                <HomeScreenList listOfItems={listOfItems} spentList={this.state.spentList} month={this.state.currentMonth} navigation={navigation} editElementList={this.props.editElementList} deleteElement={this.props.deleteElement}/>
            </Content>
        );
    }
}
const styles = StyleSheet.create({
    buttonsContent: {
        flex: 1,
        flexDirection: 'row',
    },
    buttonsStyle: {
        width: '50%',
        height: 100,
        flex: 1,
        flexDirection: 'column'
    },
    borderStyleActiveReceived: {
        borderBottomWidth: 3,
        borderBottomColor: '#228e53',
    },
    borderStyleActiveSpent: {
        borderBottomWidth: 3,
        borderBottomColor: '#cc3939',
    },
    textStyleButtons: {
        width: '100%',
        height: '100%',
    },
    numberStyle: {
        fontSize: 30,
        textAlign: 'center',
        paddingTop: 10
    },
    titleBox: {
        paddingTop: 5,
    },
    colorSpent: {
        color: '#cc3939',
    },
    colorReceived: {
        color: '#228e53',
    },
});
