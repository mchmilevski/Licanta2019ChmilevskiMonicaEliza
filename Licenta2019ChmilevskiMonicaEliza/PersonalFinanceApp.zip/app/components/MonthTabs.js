import React from 'react';
import {Button, Text} from "native-base";
import {FlatList} from "react-native";
import {getFullMonthYearWithoutCurrentYear} from "../utils/DateUtils";

export default class MonthTabs extends React.Component {
    state = {
        selectedIndex: '0',
        spentMonthListString: '',
        receivedMonthListString: '',
    };

    getMonthList = () => {
        const { spentList, listOfItems } = this.props;
        const operation = spentList ? 'Spent' : 'Received';

        let index = 0;
        let monthsInArray = new Set();
        let monthArray = [];
        for (let i = 0; i < listOfItems.length; i++) {
            if (listOfItems[i].operation !== operation) {
                continue;
            }
            const month = getFullMonthYearWithoutCurrentYear(listOfItems[i].date);
            if (!monthsInArray.has(month)) {
                monthsInArray.add(month);
                monthArray.push({key: String(index++), listOfItemsIndex: i, month: month})
            }
        }

        return monthArray;
    };

    componentDidMount() {
        const monthList = this.getMonthList();
        if (monthList.length === 0) {
            return;
        }

        this.props.updateCurrentMonth(this.props.listOfItems[monthList[0].listOfItemsIndex].date);
    }

    componentDidUpdate(prevProps, prevState, snapshot) {
        const monthList = this.getMonthList();
        if (monthList.length === 0) {
            return;
        }

        // TODO keep the same month if it exists in both places.
        const monthListString = JSON.stringify(monthList);
        if (prevProps.spentList !== this.props.spentList ||
            (this.props.spentList && this.state.spentMonthListString !== monthListString) ||
            (!this.props.spentList && this.state.receivedMonthListString !== monthListString)) {
            this.flatListRef.scrollToIndex({animated: false, index: 0, viewPosition: 0.5});
            if (this.props.spentList) {
                this.setState({selectedIndex: '0', spentMonthListString: monthListString});
            } else {
                this.setState({selectedIndex: '0', receivedMonthListString: monthListString});
            }
            this.props.updateCurrentMonth(this.props.listOfItems[monthList[0].listOfItemsIndex].date);
        }
    }

    render() {
        const { spentList, listOfItems, updateCurrentMonth } = this.props;
        return (
            <FlatList
                inverted
                horizontal
                ref={(ref) => { this.flatListRef = ref; }}
                data={this.getMonthList()}
                renderItem={
                    ({item}) => {
                        return (
                            <Button transparent
                                    onPress={() => {
                                        this.flatListRef.scrollToIndex({animated: true, index: Number(item.key), viewPosition: 0.5});
                                        this.setState({selectedIndex: item.key});
                                        updateCurrentMonth(listOfItems[item.listOfItemsIndex].date);
                                    }}
                            >
                                <Text style={item.key !== this.state.selectedIndex ? {color: '#dfdfdf'} : spentList ? {color: '#cc3939'} : {color: '#228e53'}}>
                                    {item.month}
                                </Text>
                            </Button>
                        );
                    }
                }
                contentContainerStyle={{paddingLeft: '40%'}}
                showsHorizontalScrollIndicator={false}
            />
        );
    }
}
