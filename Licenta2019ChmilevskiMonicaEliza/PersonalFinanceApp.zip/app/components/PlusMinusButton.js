import React from 'react';
import {StyleSheet} from 'react-native';
import {FAB} from 'react-native-paper';

export default class PlusMinusButton extends React.Component {
    render() {
        return (
            <FAB
                style={[styles.fab, this.props.operation === 'Spent' ? styles.backgroundSpent : styles.backgroundReceived]}
                large
                icon={this.props.operation === 'Spent' ? 'remove' : 'add'}
                onPress={() => this.props.navigation.navigate('AddMoneyScreen', {updateList: this.props.updateList, operation: this.props.operation})}
            />
        )
    }
}

const styles = StyleSheet.create({
    backgroundSpent: {
        backgroundColor: '#cc3939'
    },
    backgroundReceived: {
        backgroundColor: '#228e53'
    },
    fab: {
        position: 'absolute',
        margin: 16,
        right: 0,
        bottom: 0
    },
});
