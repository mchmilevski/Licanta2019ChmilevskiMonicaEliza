import React, {Component} from 'react';
import Swipeable from 'react-native-swipeable-row';
import {StyleSheet, View, TouchableOpacity, TouchableHighlight} from "react-native";
import {ListItem, Separator, Text, Icon, Button} from "native-base";
import 'react-native-vector-icons';
import {getFullMonthYearWithoutCurrentYear, getFormatedDate} from "../utils/DateUtils";
import {getCategoryIcon} from "../utils/CategoriesIcons";
import {totalPerDay} from "../utils/TotalUtils";

export default class HomeScreenList extends Component {

    currentlyOpenSwipeable = null;

    createList = () => {
        const operation = this.props.spentList ? 'Spent' : 'Received';
        const arrayTemp = this.props.listOfItems;

        let array = [];
        let lastDate;
        for (let i = 0; i < arrayTemp.length; i++) {

            if (arrayTemp[i].operation !== operation || getFullMonthYearWithoutCurrentYear(arrayTemp[i].date) !== this.props.month) {
                continue;
            }

            if (lastDate === undefined || new Date(lastDate.setHours(0, 0, 0, 0)).getTime() !==
                                          new Date(arrayTemp[i].date.setHours(0, 0, 0, 0)).getTime()) {
                array.push(
                    <Separator key={2019 + i} bordered style={{backgroundColor: '#f9f9f9', height: 40}}>
                        <View style={{flex: 1, flexDirection: 'row', justifyContent: 'space-between'}}>
                            <Text style={{fontSize: 15}}>{getFormatedDate(arrayTemp[i].date)}</Text>
                            <Text style={{fontSize: 15, marginRight: 15}}>Total: {totalPerDay(arrayTemp, operation, arrayTemp[i].date)}</Text>
                        </View>
                    </Separator>
                );
                lastDate = arrayTemp[i].date;
            }

            const rightButtons = [
                <Button danger style={{width: '100%', height: '100%', borderRadius: 0}} onPress={()=> {
                    if (this.currentlyOpenSwipeable) {
                        this.currentlyOpenSwipeable.recenter();
                    }
                    this.props.deleteElement(i)
                }
                }>
                    <Icon name="trash"/>
                </Button>
            ];
            const func = () => {
                if (this.currentlyOpenSwipeable) {
                    this.currentlyOpenSwipeable.recenter();
                }
            };
            array.push(
                <Swipeable
                    onRef = {ref => this.swipeable = ref}
                    rightButtons={rightButtons}
                    onRightButtonsOpenRelease = {
                        (event, gestureState, swipeable) => {
                            if (this.currentlyOpenSwipeable && this.currentlyOpenSwipeable !== swipeable) {
                                this.currentlyOpenSwipeable.recenter();
                            }
                            this.currentlyOpenSwipeable = swipeable
                        }
                    }
                >
                    <ListItem key={i} style={styles.listItemContent}>
                        <Icon style={{color: '#6d6b6b'}} name={getCategoryIcon(arrayTemp[i].category, arrayTemp[i].operation)}/>
                        <View style={styles.moneyNotesStyle}>
                            <Text style={operation === 'Spent' ? {color: '#cc3939', fontSize: 23} : {color: '#228e53', fontSize: 23}}>{arrayTemp[i].money}</Text>
                            <Text>{arrayTemp[i].notes}</Text>
                        </View>
                        <TouchableOpacity hitSlop={{top: 25, bottom: 25, left: 500, right: 20}} onPress={() => {
                            this.props.navigation.navigate('AddMoneyScreen', {editElementList: this.props.editElementList, currentElementOfList: arrayTemp[i]})
                            setTimeout(func, 300)
                        }}>
                            <Icon name="arrow-forward" style={{color: '#6d6b6b', fontSize: 24}}/>
                        </TouchableOpacity>
                    </ListItem>
                </Swipeable>
            );
        }
        array.push(<View style={{height: 80}}/>);
        return array;
    };

    render() {
        if (this.currentlyOpenSwipeable) {
            this.currentlyOpenSwipeable.recenter();
        }
        return this.createList();
    }
}

const styles = StyleSheet.create({
    listItemContent: {
        height: 60,
        flex: 1,
        flexDirection: 'row',
        justifyContent: 'space-between'
    },
    moneyNotesStyle: {
        flex: 1,
        flexDirection: 'column'
    }
});
