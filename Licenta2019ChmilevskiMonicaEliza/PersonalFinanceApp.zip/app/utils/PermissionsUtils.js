import {Constants, Notifications, Permissions} from "expo";

export {getNotificationsPermissionsAsync, getCameraPermissionsAsync};

async function getNotificationsPermissionsAsync() {
    if (Constants.isDevice) {
        let finalStatus = await getPermissionsAsync(Permissions.CAMERA);
        if (finalStatus !== 'granted') {
            return;
        }
        let token = await Notifications.getExpoPushTokenAsync();
        alert("Token: " + token);
    } else {
        console.log('Must use physical device for Push Notifications');
    }
}

async function getCameraPermissionsAsync() {
    if (Constants.isDevice) {
        return await getPermissionsAsync(Permissions.CAMERA);
    } else {
        console.log('Must use physical device for Camera');
    }
}

async function getPermissionsAsync(permission) {
    const { status: existingStatus } = await Permissions.getAsync(permission);
    let finalStatus = existingStatus;
    if (existingStatus !== 'granted') {
        const { status } = await Permissions.askAsync(permission);
        finalStatus = status;
    }
    return finalStatus;
}