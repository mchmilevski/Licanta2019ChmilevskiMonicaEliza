export {getFullMonth, getFullMonthYearWithoutCurrentYear, nextDay, getFormatedDate};

function getFullMonth(date) {
    const monthNames = ["January", "February", "March", "April", "May", "June", "July", "August", "September", "October", "November", "December"];
    return monthNames[date.getMonth()];
}

function getSorthMonth(date) {
    const monthNames = ["Jan", "Feb", "Mar", "Apr", "May", "Jun", "Jul", "Aug", "Sep", "Oct", "Nov", "Dec"];
    return monthNames[date.getMonth()];
}

function getFormatedDate(date) {
    return `${date.getDate()} ${getSorthMonth(date)} ${date.getFullYear()}`;
}

function getFullMonthYearWithoutCurrentYear(date) {
    const month = getFullMonth(date);
    const year = date.getFullYear();
    if (year === new Date().getFullYear()) {
        return month;
    }
    return month + " " + year;
}

// 0 is Sunday
function nextDay(dayOfTheWeek) {
    const returnDate = new Date();
    returnDate.setDate(new Date().getDate() + (dayOfTheWeek + ( 7 - new Date().getDay())) % 7);
    return returnDate;
}