import {Notifications} from "expo";

export {sendLocalNotification};

async function sendLocalNotification(title, body, date, repeatInterval = undefined, sound = true) {
    const localNotification = {
        title: title,
        body: body,
        android: {
            sound: sound,
        },
        ios: {
            sound: sound,
        },
    };

    const schedulingOptions = {
        time: date,
        repeat: repeatInterval
    };

    Notifications.scheduleLocalNotificationAsync(
        localNotification,
        schedulingOptions
    );
}