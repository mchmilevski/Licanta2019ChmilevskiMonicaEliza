export {getCategoryIcon};

function getCategoryIcon(category, operation) {
    if (operation === "Spent") {
        switch (category) {
            case "Grocery":
                return "ios-cart";
            case "Restaurants":
                return "ios-wine";
            case "Shopping":
                return "ios-basket";
            case "Car":
                return "ios-car";
            case "House":
                return "ios-home";
            case "School":
                return "ios-book";
            case "Saving":
                return "ios-wallet";
            case "Fun activities":
                return "ios-beer";
            case "Travel":
                return "ios-airplane";
            case "Sports":
                return "ios-fitness";
            case "Health":
                return "ios-heart";
            case "Animals":
                return "ios-paw";

            default:
                return "question"
        }
    } else {
        switch (category) {
            case "Gift":
                return "ios-gift";
            case "Salary":
                return "ios-wallet";
            case "Family":
                return "ios-people";
            case "Rent":
                return "ios-key";
            default:
                return "question"
        }
    }
}
