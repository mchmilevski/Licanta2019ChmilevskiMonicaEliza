import {AsyncStorage} from 'react-native';

export {loadObject, saveObject};

async function loadObject(key) {
    try {
        const value = await AsyncStorage.getItem(key);
        if (value !== null) {
            return JSON.parse(value, (key, value) => {
                if (key === 'date') {
                    return new Date(value);
                }
                return value;
            });
        }

        return null;
    } catch (e) {
        console.error('Failed AsyncStorage loadObject.');
    }
}

async function saveObject(key, value) {
    try {
        await AsyncStorage.setItem(key, JSON.stringify(value));
    } catch (e) {
        console.error('Failed AsyncStorage saveObject.');
    }
}
