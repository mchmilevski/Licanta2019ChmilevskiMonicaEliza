export {shuffleArray};

function shuffleArray(array) {
    array.sort(() => Math.random() - 0.5);
    return array;
}