import {getFullMonthYearWithoutCurrentYear} from "../utils/DateUtils";

export {total, totalPerCategory, totalPerWeek, totalPerDay, totalPerCategoryPerWeek, maxCategoryPerWeek};

function total(list, operation, currentMonth) {
    let total = 0;
    for (let i = 0; i < list.length; i++) {
        if (list[i].operation === operation && getFullMonthYearWithoutCurrentYear(list[i].date) === currentMonth) {
            total = total + Number(list[i].money)
        }
    }
    return total;
}

function totalPerCategory(list, category, operation, currentMonth) {
    let total= 0;
    for (let i = 0; i < list.length; i++) {
        if (list[i].operation === operation && getFullMonthYearWithoutCurrentYear(list[i].date) === currentMonth) {
            if (list[i].category === category) {
                total = total + Number(list[i].money)
            }
        }
    }
    return total;
}

function totalPerCategoryPerWeek(list, category, operation) {
    let total= 0;
    const todayTimeStamp = new Date().getTime();
    const oneWeekTimeStamp = 604800000;
    for (let i = 0; i < list.length; i++) {
        if (list[i].operation === operation && todayTimeStamp - list[i].date.getTime() < oneWeekTimeStamp) {
            if (list[i].category === category) {
                total = total + Number(list[i].money)
            }
        }
    }
    return total;
}

function maxCategoryPerWeek(list, operation) {
    let categoryTotalMap = new Map();
    const todayTimeStamp = new Date().getTime();
    const oneWeekTimeStamp = 604800000;
    for (let i = 0; i < list.length; i++) {
        if (list[i].operation === operation && todayTimeStamp - list[i].date.getTime() < oneWeekTimeStamp) {
            const total = totalPerCategoryPerWeek(list, list[i].category, operation);
            categoryTotalMap.set(list[i].category, {category: list[i].category, total: total});
        }
    }
    const categoryTotalArray = categoryTotalMap.size ? Array.from(categoryTotalMap.values()) : [];
    return categoryTotalArray.sort((a, b) => b.total - a.total)[0];
}

function totalPerWeek(list, operation) {
    let totalWeek = 0;
    const todayTimeStamp = new Date().getTime();
    const oneWeekTimeStamp = 604800000;
    for (let i = 0; i < list.length; i++) {
        if (list[i].operation === operation && todayTimeStamp - list[i].date.getTime() < oneWeekTimeStamp) {
            totalWeek = totalWeek + Number(list[i].money)
        }
    }
    return totalWeek;
}

function totalPerDay(list, operation, date) {
    let total = 0;
    for (let i = 0; i < list.length; i++) {
        if (list[i].operation === operation && list[i].date.getTime() === date.getTime()) {
            total = total + Number(list[i].money)
        }
    }
    return total;
}
