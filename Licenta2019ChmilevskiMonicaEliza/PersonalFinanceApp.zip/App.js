import React from 'react';
import HomeScreen from "./app/screens/HomeScreen";
import AddMoneyScreen from "./app/screens/AddMoneyScreen";
import Dashboard from "./app/screens/Dashboard";
import CameraScreen from "./app/screens/CameraScreen";
import {createStackNavigator, createAppContainer} from 'react-navigation';

const AppNavigator = createStackNavigator(
    {
        HomeScreen: {screen: HomeScreen},
        AddMoneyScreen: {screen: AddMoneyScreen},
        Dashboard: {screen: Dashboard},
        CameraScreen: {screen: CameraScreen}
    },
    {
        initialRouteName: "HomeScreen",
        defaultNavigationOptions: {
            headerBackTitle: 'Back'
        }
    }
);

const AppContainer = createAppContainer(AppNavigator);

export default class App extends React.Component {
    render() {
        return <AppContainer/>;
    }
}
