# Personal-Finance-Advisor
Aplicatie in care user-ul isi poate introduce banii primiti si cheltuielile dintr-o zi. Aplicatia va putea afisa o serie de statistici precum cati bani a primit, de unde, dar si cat a cheltuit pe chirie, intretinere, mancare etc intr-o anumita perioada de timp si ii poate oferi sugestii userului pentru a manage-ui mai bine banii.
